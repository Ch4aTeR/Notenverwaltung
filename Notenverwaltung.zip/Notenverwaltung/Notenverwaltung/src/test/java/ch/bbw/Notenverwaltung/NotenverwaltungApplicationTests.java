package ch.bbw.Notenverwaltung;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotenverwaltungApplicationTests {

	@Test
	void contextLoads() {
	}

}
