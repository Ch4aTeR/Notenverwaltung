# Notenverwaltung mit Java Spring-Boot und Thymeleaf

## Anforderungen:
Read/Write File:
Bei jeder Änderung einer Note oder eines Faches wird diese in einem File gespeichert.
Man kann ein File hochladen welches dann ausgelesen wird.
Die gelesenen Daten werden dann auf der Seite angezeigt.

Arrays abfüllen und erstellen:
Ich benutze Arrays zum speichern der verschiedenen Noten und Fächern.