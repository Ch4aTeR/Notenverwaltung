package ch.bbw.Notenverwaltung;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SubjectController {
    @GetMapping("/newsubject")
    public String newSubject() {
        return "newsubject";
    }

    @PostMapping("/newsubject")
    public String addNewSubject(@RequestParam("name") String name) {
        GradeService.addSubject(new Subject(name));
        return "redirect:/newgrade";
    }
}
