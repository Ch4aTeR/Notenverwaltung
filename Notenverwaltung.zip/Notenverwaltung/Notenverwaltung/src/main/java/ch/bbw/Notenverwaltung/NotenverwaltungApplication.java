package ch.bbw.Notenverwaltung;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotenverwaltungApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotenverwaltungApplication.class, args);

		Subject s1 = new Subject("Mathe");
		Subject s2 = new Subject("Eng");
		Subject s3 = new Subject("Franz");
		GradeService.addSubject(s1);
		GradeService.addSubject(s2);
		GradeService.addSubject(s3);

	}

}
