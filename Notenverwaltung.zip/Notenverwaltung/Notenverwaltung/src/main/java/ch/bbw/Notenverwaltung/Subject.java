package ch.bbw.Notenverwaltung;

public class Subject {
    private String name;
    public Subject(String name) {
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

