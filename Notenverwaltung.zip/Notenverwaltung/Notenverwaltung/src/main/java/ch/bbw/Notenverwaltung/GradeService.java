package ch.bbw.Notenverwaltung;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Service
public class GradeService {
    private List<Grade> grades = new ArrayList<>();
    private static List<Subject> subjects = new ArrayList<>();
    private final String fileName = "grades.txt";

    public void getGrades(MultipartFile file) {
        try (InputStream inputStream = file.getInputStream();
             Scanner scanner = new Scanner(inputStream)) {
            List<String> lines = Files.readAllLines(Paths.get(fileName));
            for(String line : lines) {
                String[] data = line.split(",");
                Subject subject = new Subject(data[0]);
                Double grade = Double.parseDouble(data[1]);
                grades.add(new Grade(subject, grade));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Grade> getGrades() {
        return grades;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void addGrade(Grade grade) {
        this.grades.add(grade);
        try (FileWriter fileWriter = new FileWriter("C:\\Users\\cedri\\OneDrive\\Desktop\\BBW\\Semester 5\\Modul 411\\Notenverwaltung\\Notenverwaltung\\src\\main\\resources\\grades", true)) {
            fileWriter.write(grade.getSubject() + "," + grade.getGrade() + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void addSubject(Subject subject) {
        subjects.add(subject);
    }

    public Grade getGradeById(int id) {
        for (Grade grade : grades) {
            if (grade.getId() == id) {
                return grade;
            }
        }
        return null;
    }

    public void updateGrade(Grade grade) {
        List<Grade> grades = getGrades();
        for (int i = 0; i < grades.size(); i++) {
            if (grades.get(i).getId() == grade.getId()) {
                grades.set(i, grade);
                break;
            }
        }

        try (FileWriter fileWriter = new FileWriter("C:\\Users\\cedri\\OneDrive\\Desktop\\BBW\\Semester 5\\Modul 411\\Notenverwaltung\\Notenverwaltung\\src\\main\\resources\\grades")) {
            for (Grade g : grades) {
                fileWriter.write(g.getId() + "," + g.getSubject() + "," + g.getGrade() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void readFile(@RequestParam("fileToUpload") MultipartFile file) {
        GradesController.handleFileUpload(file);
        try (InputStream inputStream = file.getInputStream();
             Scanner scanner = new Scanner(inputStream)) {
            System.out.println("<table>");
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] columns = line.split(",");
                System.out.println("<tr>");
                for (String column : columns) {
                    System.out.println("<td>" + column + "</td>");
                }
                System.out.println("</tr>");
            }
            System.out.println("</table>");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*private void saveGradesToFile() throws IOException {
        List<String> lines = new ArrayList<>();
        for (Grade grade : grades) {
            lines.add(grade.getSubject().getName() + "," + grade.getGrade());
        }
        Files.write(Paths.get("C:\\Users\\cedri\\OneDrive\\Desktop\\BBW\\Semester 5\\Modul 411\\Notenverwaltung\\Notenverwaltung\\src\\main\\resources\\grades"), lines);
    }*/
}
