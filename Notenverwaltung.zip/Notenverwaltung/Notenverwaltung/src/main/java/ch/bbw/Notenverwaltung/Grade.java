package ch.bbw.Notenverwaltung;

import javax.annotation.processing.Generated;

public class Grade {
    private int id;
    private Subject subject;
    private Double grade;

    public Grade(Subject subject, Double grade) {
        this.subject = subject;
        this.grade = grade;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Subject getSubject() {
        return subject;
    }

    public void setSubject(Subject subject) {
        this.subject = subject;
    }

    public Double getGrade() {
        return grade;
    }

    public void setGrade(Double grade) {
        this.grade = grade;
    }
}
