package ch.bbw.Notenverwaltung;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Controller
public class GradesController {

    private final GradeService gradeService;
    private final String fileName = "grades.txt";

    public GradesController(GradeService gradeService) {
        this.gradeService = gradeService;
    }

    @GetMapping("/grades")
    public ModelAndView showGrades() {
        ModelAndView modelAndView = new ModelAndView("grades");
        modelAndView.addObject("grades", gradeService.getGrades());
        return modelAndView;
    }

    @GetMapping("/newgrade")
    public ModelAndView showNewGrade() {
        ModelAndView modelAndView = new ModelAndView("newgrade");
        modelAndView.addObject("grade", new Grade(new Subject("Mathe"), 6.0));
        modelAndView.addObject("subjects", gradeService.getSubjects());
        return modelAndView;
    }

    @PostMapping("/newgrade")
    public String createNewGrade(Grade grade) {
        gradeService.addGrade(grade);
        try (FileWriter writer = new FileWriter(fileName, true)) {
            writer.write(grade.getSubject() + "," + grade.getGrade() + System.lineSeparator());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "redirect:/grades";
    }

    @GetMapping("/changegrade/{id}")
    public String showChangeGradeForm(@PathVariable("id") int id, Model model) {
        Grade grade = gradeService.getGradeById(id);
        model.addAttribute("grade", grade);
        return "changegrade";
    }

    @PostMapping("/updategrade")
    public ModelAndView updateGrade(@ModelAttribute("grade") Grade grade) throws IOException {
        gradeService.updateGrade(grade);
        return new ModelAndView("redirect:/grades");
    }


    @PostMapping("/upload")
    public static MultipartFile handleFileUpload(MultipartFile file) {
        if (!file.isEmpty()) {
            try {
                byte[] bytes = file.getBytes();
                Path path = Paths.get(file.getName());
                Files.write(path, bytes);
                //model.addAttribute("message", "File uploaded successfully!");
               // model.addAttribute("fileName", file.getOriginalFilename());
                try {
                    File gradeFile = new File(path.toUri());
                    BufferedReader br = new BufferedReader(new FileReader(gradeFile));
                    String line;
                    while ((line = br.readLine()) != null) {
                        System.out.println(line);
                    }
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (IOException e) {
               //model.addAttribute("message", "File upload failed.");
            }
        } else {
            //model.addAttribute("message", "File is empty.");
        }

        return file;
    }


}

